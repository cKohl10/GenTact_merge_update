# Blender Tactile Sensor Bay Addon
The blender tactile sensor bay addon is a tool made for procedurally generating variable density 3D printed tactile skins. This tool was designed to streamline the process of making large-scale coverage tactile sensor arrays.

# Importing the Addon:


# Applying the Skin Geometry Node:


# Saving your Configurations